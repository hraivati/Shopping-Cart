package beans;

import java.io.Serializable;

/**
 *
 * @author Chris
 */
public class MyBean implements Serializable{
    //telika tha valw ola (eisagwmena, apotelesmata pollaplasiasmwn kai prostheshs)
    private int cafequantity = 0;
    private int sugarquantity = 0;
    private int waterquantity = 0;
    
    public MyBean() {
    }
    
    public int getCafequantity() {
        return (this.cafequantity);
    }
    
    public int getSugarquantity() {
        return (this.sugarquantity);
    }
    
    public int getWaterquantity() {
        return (this.waterquantity);
    }
    
    public void setCafequantity(int cafequantity) {
        this.cafequantity = cafequantity;
    }
    
    public void setSugarquantity(int sugarquantity) {
        this.sugarquantity = sugarquantity;
    }    
    
    public void setWaterquantity(int waterquantity) {
        this.waterquantity = waterquantity;
    }   
}
