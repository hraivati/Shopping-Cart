package morejava;

/**
 *
 * @author Chris
 */
public class LinkAnaforas {
    
    private String linkAnaforas;
	
    public LinkAnaforas(String linkAnaforas) 
    {
        this.linkAnaforas = linkAnaforas;
    }

    public String getLinkAnaforas() 
    {
        return linkAnaforas;
    }        
}
